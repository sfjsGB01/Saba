https://www.anuragkapur.com/assets/blog/engineering/apache-kafka/slidesapachekafkaarchitecturefundamentalsexplained1579807020653.pdf

https://www.csee.umbc.edu/~shadam1/491s16/lectures/04-Kafka.pptx

https://events.static.linuxfound.org/sites/events/files/slides/The%20Best%20of%20Apache%20Kafka%20Architecture.pdf

https://www.slideshare.net/ClementDemonchy/kafka-101

https://docs.cloudera.com/runtime/7.2.9/kafka-overview/kafka-overview.pdf

https://www.tutorialspoint.com/apache_kafka/apache_kafka_tutorial.pdf

https://www.jfokus.se/jfokus19-preso/An-introduction-to-Apache-Kafka.pdf
