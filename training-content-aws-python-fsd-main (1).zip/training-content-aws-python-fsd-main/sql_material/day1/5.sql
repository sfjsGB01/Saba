## The ALTER TABLE statement is used to add, delete, or modify columns in an existing table.
## SQL Constraints

# Add Column
-- ALTER TABLE table_name
-- ADD column_name datatype;

Alter table hotel
add owner_email varchar(200) NOT NULL;

# Drop Column
-- ALTER TABLE table_name
-- DROP COLUMN column_name;

Alter table hotel
DROP COlUMN owner_email;

# Modify column
-- ALTER TABLE table_name
-- MODIFY COLUMN column_name datatype;

ALTER TABLE hotel
MODIFY COLUMN date_added year;

# Add checks
ALTER TABLE hotel
ADD CHECK (rating>=0);

# Add checks with constraint name
ALTER TABLE Persons
ADD CONSTRAINT CHK_rating_owner CHECK (rating>=0 AND owner is not null);

# NOTE: constraint can be created when declaring table too
CREATE TABLE parts (
    part_no VARCHAR(18) PRIMARY KEY,
    description VARCHAR(40),
    cost DECIMAL(10,2 ) NOT NULL CHECK (cost >= 0),
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE parts (
    part_no VARCHAR(18) PRIMARY KEY,
    description VARCHAR(40),
    cost DECIMAL(10,2 ) NOT NULL CHECK (cost >= 0),
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    CONSTRAINT parts_chk_price_gt_cost 
        CHECK(price >= cost)
);


## RENAME
RENAME table hotel_new to hotel2;



##### Mathematical operations
select MIN(rating) from hotel;
select MAX(rating) from hotel;
select AVG(rating) from hotel;
select SUM(rating) from hotel where city="New Delhi";
