######### CREATE DB, CREATE TABLE, INSERT ROWS, PRIMARY KEYS #########
-- Create database
CREATE DATABASE swiggy_db;

-- Delete DB
-- DROP DATABASE swiggy_db;

-- Use a database
Use swiggy_db;

-- Show tables
SHOW TABLES;

-- Create Table
CREATE TABLE hotel (
hotel_name VARCHAR(20) PRIMARY KEY, 
owner VARCHAR(20), 
city VARCHAR(20), 
date_added DATE, 
cuisine VARCHAR(20) NOT NULL,
rating INT 
);

-- OR

CREATE TABLE hotel (
hotel_name VARCHAR(20), 
owner VARCHAR(20), 
city VARCHAR(20), 
date_added DATE, 
cuisine VARCHAR(20) NOT NULL,
rating INT,
PRIMARY KEY(hotel_name) 
);

-- OR

CREATE TABLE hotel (
hotel_name VARCHAR(20), 
owner VARCHAR(20), 
city VARCHAR(20), 
date_added DATE, 
cuisine VARCHAR(20) NOT NULL,
rating INT,
CONSTRAINT PK_Hotel PRIMARY KEY (hotel_name)
);

-- Delete Table
DROP TABLE hotel;

-- see table definition
DESCRIBE hotel;

-- Inserting row into TABLE
INSERT INTO hotel
VALUES ("Mom's kitchen",'Mom','Bangalore', NOW(), 'Indian');


-- Multiple row inserts
INSERT INTO hotel
VALUES 
("Domino's",'Shyam','Ahmedabad', '1986-09-11', 'Italian', 8),
("Pizza Hut",'Aman','Goa', '1992-01-14', 'Italian', 7),
("Nagarjuna",'Bala','Mangalore', '1993-05-15', 'South Indian', 10),
("China Valley",'Eileen','Mumbai', '2021-07-18', 'Chinese', 5),
("MTR",'Mohan','Mangalore', '1998-04-22', 'South Indian', 6),
("Pujabi Dhaba",'Harpreet','Goa', '2015-09-25', 'North Indian', 8),
("Paradise",'Anoop','Hyderabad', '1993-01-11', 'South Indian', 9),
("Ali's", 'Ali','Hyderabad', '2021-05-15', 'South Indian', 7),
("Rajdhani",'Raju','New Delhi', '2015-05-05', 'North Indian', 9),
("Bawarchi",'Monu','New Delhi', '2015-05-05', 'North Indian', 8);


-- Inserting without cuisine which is a NOT NULL field.
INSERT INTO hotel
VALUES ("Rajdhani",'Raju','New Delhi', '2015-05-05');


-- Add a Primary Key in a existing table.
ALTER TABLE hotel
ADD CONSTRAINT PK_hotel PRIMARY KEY (hotel_name);

-- try adding a repetitive Primary Key - Should throw an error.
INSERT INTO hotel VALUES
("Rajdhani",'Raju','New Delhi', '2015-05-05', 'North Indian', 9);

-- selecting data from table
select * from hotel; 

-- Drop a Primary Key
ALTER TABLE hotel
DROP PRIMARY KEY;

-- COMPOSITE Primary Keys: hotels can have same name, but the owner can be different.
ALTER TABLE hotel
ADD CONSTRAINT PK_hotel PRIMARY KEY (hotel_name,owner);

-- Adding a repetitive hotel
INSERT INTO hotel VALUES
("Pizza Hut",'Claire','Santa Louis', '1992-01-15', 'Italian',4);

-- Adding a repititive hotel and owner
INSERT INTO hotel VALUES
("Paradise",'Anoop','Hyderabad', '1993-01-11', 'South Indian',2);

-- Add row with only certain columns (skipping rating, owner)
INSERT INTO hotel (hotel_name, city, date_added, cuisine) VALUES
("China Town",'Bangalore', '2005-04-11', 'Chinese');



-- ** A common practice for Primary Keys: Adding auto-increment integers **
CREATE TABLE hotel (
    hotel_id int NOT NULL AUTO_INCREMENT,
    hotel_name VARCHAR(20), 
	owner VARCHAR(20), 
	city VARCHAR(20), 
	date_added DATE, 
	cuisine VARCHAR(20) NOT NULL,
    PRIMARY KEY (hotel_id)
);

-- recreate table