#############  Querying Data #############

-- Querying data using select
select * from hotel;

-- Querying particular columns. 
select hotel_name, city from hotel;

-- Querying particular rows. I want to eat Italian.
select * from hotel where cuisine='Italian';

-- Multi conditionals: I am in NY and I want to it Italian.
select * from hotel where cuisine='Italian' and city='New York';

select * from hotel where hotel_name='Pizza hut' or cuisine='Italian'; 

select * from hotel where rating BETWEEN 8 AND 10;

select * from hotel where city IN ('New Delhi', 'Goa');

select * from hotel where rating is NULL;
select * from hotel where rating is NOT NULL;

-- comparision operators
select * from hotel where cuisine <> 'Italian';
select * from hotel where rating >= 7;

-- select distinct
select distinct city from hotel;

select distinct city, cuisine from hotel;


-- alias

select rating as hotel_rating from hotel;
select avg(rating) as average_rating from hotel where city='Goa';

-- table aliasing
select h.hotel_name, h.rating from hotel h where h.city='Mumbai';