-- 1. Keywords may be entered in any lettercase.
SELECT VERSION(), CURRENT_DATE;
select version(), current_date;

-- 2. Can be used as a calculator.
SELECT SIN(PI()/4), (4+1)*5;

-- 3. You can even enter multiple statements on a single line. Just end each one with a semicolon
SELECT VERSION(); SELECT NOW();

-- 4. simple multiple-line statement
SELECT USER()
,
CURRENT_DATE;

show databases;
show tables;