-- Date operations
SELECT hotel_name, date_added, TIMESTAMPDIFF(YEAR,date_added, CURDATE()) AS age FROM hotel;

-- Pattern Matching
SELECT * FROM hotel WHERE city LIKE 'New%';

SELECT * FROM hotel WHERE hotel_name LIKE '%Dhaba';

SELECT * FROM hotel WHERE hotel_name LIKE '%no%';

SELECT * FROM hotel WHERE hotel_name LIKE '_____';

# To find names beginning with b, use ^ to match the beginning of the name:
SELECT * FROM hotel WHERE hotel_name REGEXP '^N'; 
# Use $ to match the end
SELECT * FROM hotel WHERE city REGEXP 'lore$';
SELECT * FROM hotel WHERE hotel_name REGEXP '^.....$';
SELECT * FROM hotel WHERE hotel_name REGEXP '^.{5}$';

-- sort
select * from hotel order by date_added;
select * from hotel order by date_added DESC;
select * from hotel order by cuisine, date_added;

-- limit
select * from hotel order by date_added limit 3;

-- Pagination, Lazy Loading in applications.

select * from hotel order by date_added limit 3 offset 3;

# count

SELECT COUNT(*) FROM hotel;
SELECT city, COUNT(*) FROM hotel GROUP BY city;


###### Update rows ###########
UPDATE hotel
SET owner='Lalit'
WHERE hotel_name='China Town';

UPDATE hotel
SET owner='Vikram', cuisine='Asian'
WHERE hotel_name='China Town';


# copy data from 1 table to another
CREATE TABLE hotel_new LIKE hotel;
INSERT INTO hotel_new SELECT * FROM hotel;



##### DELETE Rows ######

DELETE from hotel
where hotel_name='China Town';

DELETE FROM hotel
order by date_added
LIMIT 2;

