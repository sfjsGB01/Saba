-- stored procedures
-- database design exercise
use classicmodels;
DELIMITER $$

CREATE PROCEDURE GetCustomers()
BEGIN
	SELECT 
		customerName, 
		city, 
		state, 
		postalCode, 
		country
	FROM
		customers
	ORDER BY customerName;    
END$$
DELIMITER ;



-- Delimiter: MySQL sees ; as a delimiter for multiple SQL stmts. SQL should consider SP as a single stmt.
-- Hence we temporarily change the delimiter

CALL GetCustomers();


DROP PROCEDURE GetCustomers;

-- DROP PROCEDURE IF EXISTS abc;


DELIMITER $$

CREATE PROCEDURE GetOrderAmount()
BEGIN
    SELECT 
        SUM(quantityOrdered * priceEach) 
    FROM orderDetails;
END$$

DELIMITER ;

-- Modifying SP
DELIMITER $$
CREATE PROCEDURE GetOrderAmount(
IN pOrderNumber INT
)
BEGIN
    SELECT 
        SUM(quantityOrdered * priceEach) 
    FROM orderDetails
    where orderNumber = pOrderNumber;
END$$
