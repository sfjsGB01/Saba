-- declaring variables

-- DECLARE variable_name datatype(size) [DEFAULT default_value];
-- Ex : DECLARE totalSale DEC(10,2) DEFAULT 0.0;
-- DECLARE x, y INT DEFAULT 0;


-- Assigning variables
-- SET variable_name = value;

-- DECLARE total INT DEFAULT 0;
-- SET total = 10;

--  you can use the SELECT INTO statement to assign the result of a query to a variable;
-- DECLARE productCount INT DEFAULT 0;

-- SELECT COUNT(*) 
-- INTO productCount
-- FROM products;


DELIMITER $$

CREATE PROCEDURE GetTotalOrder()
BEGIN
	DECLARE totalOrder INT DEFAULT 0;
    
    SELECT COUNT(*) 
    INTO totalOrder
    FROM orders;
    
    SELECT totalOrder;
END$$

DELIMITER ;

CALL GetTotalOrder();

