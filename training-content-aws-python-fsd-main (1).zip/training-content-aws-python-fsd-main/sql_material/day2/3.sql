-- ANY, ALL, CASE, Views, Indexing

use classicmodels;
select * from orderdetails;
select * from products;

-- ANY: returns bool value as a result. True if subquery meets condition.
select productName from products where productCode = ANY(
select productCode from orderdetails where quantityOrdered = 15);

-- ALL: returns bool value as a result. True if ALL subquery values meets condition.
select productName from products where productCode = ALL(
select productCode from orderdetails where quantityOrdered = 10);

-- CASE
select orderNumber, quantityOrdered,
CASE
	WHEN quantityOrdered > 30 THEN 'The quantity is greater than 30'
    WHEN quantityOrdered = 30 THEN 'The quantity is 30'
    ELSE 'The quantity is under 30'
END as QuantityText
FROM orderdetails;

-- handling NULLs

select productName,
IFNULL(quantityInStock,0) * buyPrice as totalValue
from products where productName='a';

-- COALESCE: returns first non null value from the list
select productName,
COALESCE(quantityInStock,0) * buyPrice as totalValue
from products where productName='a';


-- ============================= VIEWS ===========

select * from products;

-- We want to see a specific data about customer and their payments over and over again.
SELECT 
    customerName, 
    checkNumber, 
    paymentDate, 
    amount
FROM
    customers
INNER JOIN
    payments;
    
CREATE VIEW customerPayments
AS 
SELECT 
    customerName, 
    checkNumber, 
    paymentDate, 
    amount
FROM
    customers
INNER JOIN
    payments;
    
    
SELECT * FROM customerPayments;


CREATE VIEW daysofweek (day) AS
    SELECT 'Mon' 
    UNION 
    SELECT 'Tue'
    UNION 
    SELECT 'Web'
    UNION 
    SELECT 'Thu'
    UNION 
    SELECT 'Fri'
    UNION 
    SELECT 'Sat'
    UNION 
    SELECT 'Sun';
    
SELECT * FROM daysofweek;

-- Rename views
RENAME TABLE original_view_name 
TO new_view_name;

-- Drop view
DROP VIEW IF EXISTS customerPayments;


-- ==================== MySQL Indexes ==============
-- MySQL uses indexes to quickly find rows with specific column values. 
-- Without an index, MySQL must scan the whole table to locate the relevant rows. 
-- The larger table, the slower it searches.
-- Similar to a dictionary
-- Uses B-Tree behind the scenes

CREATE TABLE t(
   c1 INT PRIMARY KEY,
   c2 INT NOT NULL,
   c3 INT NOT NULL,
   c4 VARCHAR(10),
   INDEX (c2,c3) 
);


CREATE INDEX index_name ON table_name (column_list);

EXPLAIN SELECT 
    employeeNumber, 
    lastName, 
    firstName
FROM
    employees
WHERE
    jobTitle = 'Sales Rep';
    
CREATE INDEX jobTitle ON employees(jobTitle);


SHOW INDEXES FROM employees;
