#### Joins ####

select * from productlines;
select * from products;

select * from productlines pl
inner join products p
on pl.productLine = p.productLine;

select * from productlines pl
inner join products p
on pl.productLine = p.productLine where pl.productLine like '% Cars';

select * from customers;
select * from orders;

SELECT
    c.customerNumber,
    customerName,
    orderNumber,
    status
FROM
    customers c
INNER JOIN orders o 
    ON c.customerNumber = o.customerNumber;


SELECT
    c.customerNumber,
    customerName,
    orderNumber,
    status
FROM
    customers c
LEFT JOIN orders o 
    ON c.customerNumber = o.customerNumber;
    
    
SELECT
    c.customerNumber,
    customerName,
    orderNumber,
    status
FROM
    customers c
RIGHT JOIN orders o 
    ON c.customerNumber = o.customerNumber;
    
    
SELECT
    c.customerNumber,
    customerName,
    orderNumber,
    status
FROM
    customers c
CROSS JOIN orders o -- notice number of rows in the output
    ON c.customerNumber = o.customerNumber; #### what happens when we add this condition?
    
    
    
-- SELF Join

select * from employees;

select e.firstname, e.lastname, m.firstname, m.lastname
from employees e inner join employees m
on e.reportsTo = m.employeeNumber;

select CONCAT(e.firstname, ' ', e.lastname) as employee_name, CONCAT(m.firstname, ' ', m.lastname) as manager
from employees e inner join employees m
on e.reportsTo = m.employeeNumber
order by manager;