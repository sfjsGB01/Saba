-- Subquery | Exists | Not exists | Having
use classicmodels;
select * from offices;
select * from employees;
select * from payments;

-- Subquery
SELECT lastName, firstName
FROM employees
WHERE officeCode IN (
	SELECT  officeCode
	FROM offices
	WHERE country = 'USA');
    
-- Subquery with comparision operator
SELECT customerNumber, checkNumber, amount
FROM payments
WHERE amount > (SELECT AVG(amount) FROM payments);

-- subquery with EXISTS/NOT EXISTS
-- find the customer who has at least one order
SELECT customerNumber, customerName
FROM customers
WHERE EXISTS(SELECT 1 FROM orders WHERE orders.customernumber = customers.customernumber);


-- insert customers who do not have any sales order into the customers_archive table
INSERT INTO customers_archive
SELECT * 
FROM customers
WHERE NOT EXISTS( 
   SELECT 1
   FROM
       orders
   WHERE
       orders.customernumber = customers.customernumber
);


-- Having

-- Build a query to get order number and items sold per order and total sales for each 
SELECT 
    ordernumber,
    SUM(quantityOrdered) AS itemsCount,
    SUM(priceeach*quantityOrdered) AS total
FROM
    orderdetails
GROUP BY ordernumber;

--  find which order has total sales greater than 1000 by using the HAVING clause as follows:

SELECT 
    ordernumber,
    SUM(quantityOrdered) AS itemsCount,
    SUM(priceeach*quantityOrdered) AS total
FROM
    orderdetails
GROUP BY 
   ordernumber
HAVING 
   total > 1000;