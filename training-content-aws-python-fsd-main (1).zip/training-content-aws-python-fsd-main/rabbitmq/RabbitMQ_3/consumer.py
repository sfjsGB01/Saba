# Fanout Exchange
# It is RabbitMQ's responsibility to distribute messages to consumers.
# Consumers do not demand messages.
# Setting prefetch count helps distribute messages to multiple consumers in a particular fashion.
import pika
import time

def main():
    # creating a connection
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    # creating a channel within connection
    channel = connection.channel()
    # creating exchange
    channel.exchange_declare(exchange="logs", durable=True, exchange_type='fanout')
    # creating queue: Letting Rabbitmq CREATE AND NAME THE QUEUE
    result = channel.queue_declare(queue='', exclusive=True)
    queue_name = result.method.queue

    # binding the queue and exchange
    channel.queue_bind(exchange='logs', queue=queue_name)

    def callback(ch, method, properties, body):
        print('Received {}'.format(body))
        print("Done")
        # ch.basic_ack(delivery_tag=method.delivery_tag)

    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    print('Waiting for messages')
    channel.start_consuming()


if __name__=='__main__':
    main()