# Fanout Exchange
# import library
import pika, sys

# establish connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
# establish a channel
channel = connection.channel()
# create a exchange
channel.exchange_declare(exchange="logs", durable=True, exchange_type='fanout')

# get a message
message = ' '.join(sys.argv[1:]) or "Info: Sample message"

print(message)
# publish a message
channel.basic_publish(exchange='logs', routing_key='', body=message)
print("Sent a message")

# close the connection
connection.close()