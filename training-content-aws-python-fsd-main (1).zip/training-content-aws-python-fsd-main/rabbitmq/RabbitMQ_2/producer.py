# import library
import pika, sys

# establish connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
# establish a channel
channel = connection.channel()
# create a queue
channel.queue_declare(queue="task_queue", durable=True)

# get a message
message = ' '.join(sys.argv[1:]) or "Sample message"

print(message)
# publish a message
channel.basic_publish(exchange='', routing_key='task_queue', body=message)
print("Sent a message")

# close the connection
connection.close()