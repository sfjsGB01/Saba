# Direct Exchange
# import library
import pika, sys

# establish connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
# establish a channel
channel = connection.channel()
# create a exchange
channel.exchange_declare(exchange="direct_logs", durable=True, exchange_type='direct')

# get a message
# message = ' '.join(sys.argv[1:]) or "Info Sample message"
severity = sys.argv[1] or 'info'
message = ' '.join(sys.argv[2:]) or "Sample message"
# python producer.py info log message

print(message)
# publish a message
channel.basic_publish(exchange='direct_logs', routing_key=severity, body=message)
print("Sent a message")

# close the connection
connection.close()