# Direct Exchange
# Producer
# ========
# [Timestamp][log_level (severity)][message]

# info App got started
# info processed customer 1
# warn customer 2 does not exist
# critical db not reachable


# Consumer
# Q1: info
# Q2: warn
# Setting prefetch count helps distribute messages to multiple consumers in a particular fashion.
import pika
import time, sys

def main():
    # creating a connection
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    # creating a channel within connection
    channel = connection.channel()
    # creating exchange
    channel.exchange_declare(exchange="direct_logs", durable=True, exchange_type='direct')
    # creating queue: Letting Rabbitmq CREATE AND NAME THE QUEUE
    result = channel.queue_declare(queue='', exclusive=True)
    queue_name = result.method.queue

    severity_list = sys.argv[1:]

    if not severity_list:
        print('ERROR: Please give a severity')
        return
    
    for severity in severity_list:
        channel.queue_bind(exchange='direct_logs', queue=queue_name, routing_key=severity)

    # binding the queue and exchange
    # channel.queue_bind(exchange='logs', queue=queue_name)

    def callback(ch, method, properties, body):
        print('Received {}'.format(body))
        print("Done")
        # ch.basic_ack(delivery_tag=method.delivery_tag)

    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    print('Waiting for messages')
    channel.start_consuming()


if __name__=='__main__':
    main()

# Exercise: Try to revise Topic exchange and code it out 
# ref: https://www.rabbitmq.com/tutorials/tutorial-five-python.html