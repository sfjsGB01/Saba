# It is RabbitMQ's responsibility to distribute messages to consumers.
# Consumers do not demand messages.
import pika, sys, os

def main():
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='hello')

    def callback(ch, method, properties, body):
        print(ch)
        print(method)
        print(properties)
        print('Received {}'.format(body))

    channel.basic_consume(queue='hello', on_message_callback=callback, auto_ack=True)
    print('Waiting for messages')
    channel.start_consuming()


if __name__=='__main__':
    main()