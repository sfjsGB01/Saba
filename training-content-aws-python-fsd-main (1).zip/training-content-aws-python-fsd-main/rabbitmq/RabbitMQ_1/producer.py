# import library
import pika

# establish connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
# establish a channel
channel = connection.channel()
# create a queue
channel.queue_declare(queue="hello")
# publish a message
channel.basic_publish(exchange='', routing_key='hello', body='Hello World!!')
print("Sent a message")

# close the connection
connection.close()