https://www.slideshare.net/knoldus/introduction-to-rabbitmq
