'''
Contains functions corresponding to the endpoints of store related APIs.
logic for processing these APIs.
'''

from flask_restful import Resource, reqparse
from app.models.store import StoreModel
from flask_jwt_extended import jwt_required

class Store(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('store_owner', type=str, required=True, help='store owner is a required field')

    def get(self, name):
        store = StoreModel.find_by_name(name=name)
        if store:
            # we will do the task to return the store in JSON format
            return store.json()
        return {'message': 'Store not found'}, 404

    def post(self, name):
        data = Store.parser.parse_args()
        
        if StoreModel.find_by_name(name):
            return {"message": f"Store with name: {name} already exists"}, 400
        
        store = StoreModel(name, data['store_owner'])
        try:
            store.save_to_db()
        except Exception as ex:
            print("Exception while trying to add a store: {}".format(ex))
            return {"message": "Exception while trying to add a store: {}".format(ex)}, 500
        
        return store.json(), 201

    @jwt_required()
    def delete(self, name):
        store = StoreModel.find_by_name(name)
        if store:
            store.delete_from_db()
            return {"message": "store deleted"}
        
        return {"message": "store does not exist"}, 400


class StoreList(Resource):
    def get(self):
        return {'stores': [store.json() for store in StoreModel.query.all()]}