# pip install requests
import json
from urllib import response
import requests

BASE_URL = 'https://fakestoreapi.com'

# Get All products
all_products_response = requests.get(f"{BASE_URL}/products")
print(all_products_response.json())

for product in all_products_response.json():
    print(f"{product['title']} costs ${product['price']}" )


# Get single product
products_5_response = requests.get(f"{BASE_URL}/products/10")
print(products_5_response.json())


# Get products with a limit with query params
query_params = {"limit": 4}
products_limit_response = requests.get(f"{BASE_URL}/products", params=query_params)
print(products_limit_response.json())

# Get sorted products with query params
query_params = {"sort": "desc"}
products_sort_response = requests.get(f"{BASE_URL}/products", params=query_params)
print(products_sort_response.json())

# get product categories
products_category_response = requests.get(f"{BASE_URL}/products/categories")
print(products_category_response.json())

# add a product

new_product = {
                    "title": 'test product-new',
                    "price": 13.5,
                    "description": 'lorem ipsum set',
                    "image": 'https://i.pravatar.cc',
                    "category": 'electronic'
                }
response = requests.post(f"{BASE_URL}/products", json=new_product)
print(response.json())

headers = {
    "Content-Type": "application/json"
}
response = requests.post(f"{BASE_URL}/products", data=json.dumps(new_product), headers=headers)
print(response.json())

# update a product
update_prod = {
    "title": 'test product- x',
    "price": 13.5,
    "description": 'lorem ipsum set',
    "image": 'https://i.pravatar.cc',
    "category": 'electronic'
}

response = requests.put(f"{BASE_URL}/products/1", json=update_prod)
print(response.json())


# Delete a product

res = requests.delete(f"{BASE_URL}/products/11")
print(res.json())
