### REST:
https://www.youtube.com/watch?v=HeXQ98sogs8&list=PLWPirh4EWFpGRdVZcQCzeTXFBNSTDAdQX&ab_channel=TutorialsPoint%28India%29Ltd
https://www.slideshare.net/hburakcetinkaya/rest-res-tful-web-services
https://www.slideshare.net/AniruddhBhilvare/an-introduction-to-rest-api

### JSON
https://www.w3schools.com/js/js_json_syntax.asp
https://www.slideshare.net/jfox015/json-22195683

