# Type cpnversion/ Type casting: convert a value from 1 datatype to another
a = 123
b = "456"
c = {8,9,0}

print(type(a))
print(type(b))
print(type(c))

# converting a from int to str
a_string = str(a)
b_int = int(b)
c_list = list(c)

print(type(a_string))
print(type(b_int))
print(type(c_list))

# taking input from a  user

# item = input("Enter your favorite item: icecream, candy, pastry")
# print(item)

num = int(input("Enter your favorite number"))
print(type(num))