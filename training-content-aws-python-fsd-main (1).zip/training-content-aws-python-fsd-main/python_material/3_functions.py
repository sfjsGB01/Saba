# functions: Meant to do a particular repetitive task
# functions with parameters, default parameters
# functions returning a value
# scope of variables in a function block / Using global variables within a function
# docstring: description of function
def greet(name):
    """
    Greets people with supplied name
    Parameters:
        name: person's name
    """
    greeting_string = f"Hi {name}"
    print(greeting_string)

# name = input("enter your name")
# greet(name)
name_1 = "Aman"
greet(name_1)
greet("Sachin")

# get docstring of a function
print(greet.__doc__)

def add (a,b,c):
    sum = a+b+c
    print(sum)

add(10,20,30)

# default parameters: Even if the value is not supplied, python uses default value of the parameter to work with
# NOTE: must be used in the last of parameter sequence

def smart_greet(name, greet="Hey"):
    print(f"{greet} {name}")

smart_greet("aman", "hi")
smart_greet("Bob", "Welcome")
smart_greet("Tom")

# Named Parameters

smart_greet(name="Rayn", greet="Hola")
smart_greet(greet="Hola", name="Rayn")

# return values: return single or multiple values

def divide(a,b):
    result = a//b
    # print(result)
    return result, True

val, is_success = divide(10,5)
print(val, is_success)


# scope of variables
# variables local to a function are scoped only in that block
def my_func():
    global x
    print(f"value inside {x}")
    x = 21
    print(f"value inside {x}")

x = 100
my_func()
print(f"value outside {x}")


# Anonymous functions/ lambda functions: Functions without a name
# these are short lived functions and usually can be written in a single line
# Syntax : lambda arguments: expression

square = lambda nn: nn**2

print(square(10))


# calling a function within a loop
def mult_by_2(number):
    return number*2

number_list = [1,2,3,4,5,6,7,8,9]
for number in number_list:
    res = mult_by_2(number)
    print(res)




# *args and **kwargs
# *args: Takes any number of arguments into a function as a tuple. Number of args can be dynamic
def adder (x,y,z, a =0, b=0):
    print(f"sum is : {x+y+z+a+b}")

adder(1,2,3)
adder(1,2,3,4,5) # : Gives an error


def smart_adder(*nums):
    print(nums)
    sum = 0
    for num in nums:
        sum = sum + num
    return sum

print(smart_adder(1,2,3))
print(smart_adder(1,2,3,4,5))
print(smart_adder(1,2,3,4,5,33,44))
print(smart_adder(1,2,3,4,5,5,3,3,5,3,2,4,32))

