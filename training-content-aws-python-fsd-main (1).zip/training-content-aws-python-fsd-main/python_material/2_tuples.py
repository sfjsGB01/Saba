# Tuples are not mutable. They cannot be updated and modified after declaration

# tuples: Immutable (read only) - faster than lists

t = (2, 'aman', 3.4, 'hi')
print(t)

# print(t[:2])
# print(t[-2])
# print(t[1:4])
# print(t[1:14])

# check mutability
# t[2] = 'qwerty'
# print(t) ## Results in an error as tuple is immutable.

print(t[1])