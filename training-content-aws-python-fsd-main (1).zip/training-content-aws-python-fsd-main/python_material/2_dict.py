# Dictionary: Unordered list of key value pairs.
# Optimized for retrieving data. time Complexity O(1)
# in python: Mutable. Similar to json.


# Declaring a dictionary
# type1: when the values are not known during initialization and they have to be added dynamically.
contact_dict = {}
print(type(contact_dict))

# contact_dict["key"] = value
contact_dict["Raj"] = 987
contact_dict["Vivek"] = 444
contact_dict["Varghese"] = 888

# type 2: when the values are already known during initialization
# KEYS: datatypes that are immutable are allowed in the keys of a dict.
# KEYS can be unique but values can be the same or different

name_dict = {
    "Aman": 987,
    "Byju": 465,
    "Chetan": 987,
}

# access values of a particular key
print(name_dict["Chetan"])
print(contact_dict["Raj"])

# update dictionary value
name_dict["Aman"] = 555
print(name_dict)

name_dict["Doug"] = 787
print(name_dict)

# print(name_dict["zed"])

# Get all the keys and values from a dict
print(list(name_dict.keys()))
print(list(name_dict.values()))

d = {
    "i": 11,
    "l": [1,2,3],
    1: ("name", "age"),
    "s": {7,8,8,9},
    "d": {"a":1, "b":2, "c":3}
}

print(d['l'][1])
print(d[1][0])
print(d["d"]["c"])

# Membership operator: "in" "not in"
print("t" in list(d["d"].keys()))

print("k" not in list(d["d"].keys()))