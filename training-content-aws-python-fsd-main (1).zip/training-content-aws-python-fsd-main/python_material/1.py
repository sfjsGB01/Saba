# Basic Stuff for python intro

print("Hello world!")

a = 10
print(a)

b = 10.13
c = "This is a string"
# printing multiple values with different datatypes
print(b, c)

# formatting (available from python 2 and onwards)
print("a = {}, b = {}, c= {}".format(a,b,c))
print("this is {}, that is {}".format(c,b))
#this is This is a string, that is 10.13
print("a = {1}, b = {0}, c= {2}".format(a,b,c))

name = "aman"
age = 12
print(f"my name is {name} and my age is {age}") # >= python 3.6

# multiple assignments
a = b = c = 22

"""
This is a  multiline comment
This is second line

Python treats single quotes and double quotes the same
"""

z = 'Ramesh'
# escape quotes
z1 = 'This is Aman\'s laptop'
z2 = "this is Sumeet's file"
z3 = 'John said "I am unwell"'