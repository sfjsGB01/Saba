# Numbers
a = 3
b = 20
print(a + b)
print(a - b)
print(b/a)
print(b//a) # 6 - floor division
print(b*a)
print(b**a) # exponent operator

print(max(a,b))
print(min(a,b))