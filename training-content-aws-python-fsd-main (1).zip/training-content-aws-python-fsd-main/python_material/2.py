# Data types
"""
1. Number - 11, 11.13, - 89, x2d,..
2. String
3. List
4. Tuple
5. Dictionary (similar to JSON)
6. Sets
"""
# Numbers
a = 3
b = 20
print(a + b)
print(a - b)
print(b/a)
print(b//a) # 6 - floor division
print(b*a)
print(b**a) # exponent operator

print(max(a,b))
print(min(a,b))

# Strings
s = "My name is aman"
s1 = 'this is a banana' # single quotes and double quotes are treated the same in python.
s2 = "this is aman's laptop"
s3 = 'this is aman\'s laptop'
print(s2)
print(s1)
print(s[0])
print(s[0:5])
print(s[5:])
print(s * 2)
print(s + " and my age is 18")
print(f"length of string s1 is: {len(s1)}") # calculate length of a string


# Lists: not confined to a particular size or variable type
l = [1, 2, 3, "string", "aman", 3.3,2,2,3,3]
l1 = [12,13,14]
print(l)
print(l[0])
print(l[3])
print(l[2:4])
print(l[3:])
print(l[:5])

# lists are mutable
l[0] = 100
print(l)
l.append(400)
print(l)

# negative indices
print(l[-1]) #will always be the last value
print(l[-1:-4])
print(l[-4:-1])

# functions with respect to list
print(len(l))

print(l+l1)


# tuples: Immutable (read only) - faster than lists
t = (2, 'aman', 3.4, 'hi')
print(t)

print(t[:2])
print(t[-2])
print(t[1:4])
print(t[1:14])

# check mutability
# t[2] = 'qwerty'
# print(t) ## Results in an error as tuple is immutable.

# sets
# order is not maintained.
# duplicates are removed by sets inherently.

set_s = set() ## declare an empty set
print(type(set_s))

s = {"My", "name", "is", "aman", "name", 1,1,3,45,5,5}

print(s)

s.add(100)
print(s)
s.remove("name")


set_from_list = set(l)
print(set_from_list)


s1 = {1,2,3, "a"}
s2 = {"a", "b", "c",1,2}
s3 = s1.union(s2)
print(s3)

# s1.update(s2)
# print(s1)

s4 = s1.intersection(s2)
print(s4)


# Dictionary in python: Mutable. Similar to json.
# Declaring a dictionary
contact_dict = {}
print(type(contact_dict))

contact_dict["aman"] = 987677
contact_dict["joseph"] = 55343
contact_dict["Edyy"] = 24343
contact_dict["Ivan"] = 23254

print(contact_dict)

# Declaring a dictionary
fruit_price_dict = {
    "Banana": 10,
    "Apple": 1,
    "Mango": 3,
    "Cherry": 5
}
print(fruit_price_dict)

# Accessing elements of a dictionary
print(f"The price of apple is: {fruit_price_dict['Apple']}")
print(fruit_price_dict["Cherry"])
# print(fruit_price_dict["watermelon"]) results in a error. No key present in the dict.

# price of mango shooted up
fruit_price_dict["Mango"] = 5
print(fruit_price_dict["Mango"])

# get all the keys
print(list(fruit_price_dict.keys()))
# get all the values
print(list(fruit_price_dict.values()))


# dictionary with various datatypes
dd = {
    1: ["asd",3,4, "fd"],
    "str": (1,2,3),
    "str2": {2,341},
    "d": {"a":1, "b":2, "c":3}
}
print(dd[1][2])
print(dd["d"]["c"])
print(type(dd))

# Accessing an element within a dict: Time complexity O(1)
# Why: because python internally stores keys as hashes. and the entire dict as hash tables. So accessing is in O(1).



