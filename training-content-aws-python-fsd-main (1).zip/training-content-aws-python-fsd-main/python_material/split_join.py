l = ["John", "Kumar", "Bangalore", "India"]
# join them all together in a string with space a separator
# "John Kumar 22 Bangalore India"

# Joining
x = " ".join(l)
print(x)

x = "-&".join(l)
print(x)

#splitting
s = "This is a beautiful scene"
l = s.split()
print(s)

ss = "aman john Naseem Sachin"