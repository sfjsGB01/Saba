# sets
# order is not maintained.
# duplicates are removed by sets inherently.
# sets is mutable, it can be updated after declaration

set_s = set() ## declare an empty set
print(type(set_s))


s = {"My", "name", "is", "aman", "name", 1,1,3,45,5,5}

print(s)

# adding and removing elements from set
s.add(100)
s.add(100)
print(s)
s.remove("name")
print(s)

# convert list to set and removed duplicates
l = [1,2,3,4,2,3,2,2,4,1]
set_from_list = set(l)
print(set_from_list)


s1 = {1,2,3, "a"}
s2 = {"a", "b", "c",1,2}
s3 = s1.union(s2)
print(s3)


# s1.update(s2)
# print(s1)


s4 = s1.intersection(s2)
print(s4)
