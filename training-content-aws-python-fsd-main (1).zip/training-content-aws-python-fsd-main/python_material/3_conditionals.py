# conditionals: if, if-else, if-elif-else

from re import A


score = 85
if score >= 90:
    print("Grade A")
else:
    print("Your grade is not A")

if score >=90:
    print("Grade A")
elif score >= 80 and score < 90:
    print("Grade B")
elif score >= 70 and score < 80:
    print("Grade C")
elif score >= 60 and score < 70:
    print("Grade D")
else:
    print("You have failed")

# find maximum number out of 1,2,3
a,b,c = 1,2,3
if a > b:
    if a > c:
        print("a is the highest")