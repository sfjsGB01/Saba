# for, while, continue-break, range(), pass

names= ["Aman", "Byju", "Chetan", "Doug", "Keshav", "Eric"]

for name in names:
    print(f"HI {name}")


# Range Sytax: range(start, stop, step)
print(list(range(10))) # gives all the consecutive values from start to end
print(list(range(5,10))) # second value is exclusive
print(list(range(1, 50, 5)))

for i in range(3):
    print(names[i])

# for-else loop
for num in range(5):
    print(num)
else:
    print("loop done")


# While loop
q = 1
while q <= 10:
    print(q)
    q = q + 1
else:
    print(" we have reached 10")

# continue - break
s = "This is nam.an"
for c in s:
    if c == 'i':
        continue
    elif c == '.':
        break
    else:
        print(c)

# check whether 400 exists in the list
l = [21,22,23,400,5,3,2,1]
for n in l:
    if n == 400:
        print("400 is present")
        break

# membership operator - in / not in
if 400 in l:
    print("exists")
else:
    print("not exists")


# pass: does nothing. only for indicating python that block is valid.

for n in l:
    if n == 13:
        print("found 3")
    else:
        pass

class Person:
    # this is an empty class
    pass