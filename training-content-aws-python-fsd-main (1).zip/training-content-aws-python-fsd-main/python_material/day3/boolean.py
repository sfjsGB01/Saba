# boolean: True/False (T/F are caps in python)
# False always represnts value 0

a = True
b = False
print(a,b)

i = 0
while True:
    print(i)
    i += 2          # i = i+2 
    if i == 20:
        break


# False always represnts value 0
j = 10
while j:
    print(j)
    j -= 1

print(True and False)
print(True or False)