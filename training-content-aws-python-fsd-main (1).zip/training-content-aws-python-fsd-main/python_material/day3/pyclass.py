

# Python classes: Represent an object. EX: Person, Animal, Directory File Structure, Data Structures like linkedlist, arrays, queues, stacks etc
# Custom datatype created by dev on a need basis.
# Inbuilt datatypes: lists, strings, integers, boolean, tuple, dict

class Person:
    # Class attributes
    # firstname
    # lastname
    # gender
    # address
    # DOB
    # Class attributes - The attributes that are common is usually kept as class attributes
    legs=2
    firstname = "Ram"
    lastname = "Charan"
    gender = "Male"
    address = "Hyderabad"
    dob = "2000-01-01"

# instance of the class / object of the class
p1 = Person()

# accessing attributes
print(f"Name: {p1.firstname} {p1.lastname}, address: {p1.address}")

# update instance's attribute value
p1.address = "Chennai"
print(p1.address)

p2 = Person()
print(p2.firstname)

# even when we have multiple persons (instances of Person class), we still have same attribute values (ex; firstname = Ram)

from types import CoroutineType
from unicodedata import name


class Person2:
    # constructor: it is primarily used to initiate an object.
    # it is called by default when we create an object of the class.
    def __init__(self):
        print("I am init")

    
    
print("before creating object")
p = Person2()
print("after creating object")


class Person_generic:
    # class attributes
    eyes = 2
    # self represents object we are trying to create
    def __init__(self, x, y, z):
        # instance attributes
        self.name = x
        self.city = y
        self.age = z
        print(f"Created a person with name: {x}")

    def greet(self):
        print(f"Hi {self.age}")


p11 = Person_generic('Aman', 11, 'New York')
p12 = Person_generic('Bob', 30, 'Seattle')

p12.greet()


# accessing variables
print(p11.name)
print(p11.city)
print(p12.age)

print(p11.eyes)
print(p12.eyes)

# update
p11.age = 12

print(f"name = {p11.name}, age: {p11.age}")
