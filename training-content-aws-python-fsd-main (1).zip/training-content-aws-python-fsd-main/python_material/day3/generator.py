# def gen():
#     a = 1
#     print("this is a =1")

#     yield a

#     a += 1
#     print("this is a=2")

#     yield a

#     a+=1
#     print("this is a=3")

#     yield a

# # function call returned an object of type generator but did not actually execute the function
# a = gen()
# # print(a)
# print("first next")
# print(next(a))
# print("second next")
# print(next(a))
# print("third next")
# print(next(a))




########
# yield will stop the execution of current function and return the value to the caller (usually next())

def generate_sequence(x):
    # [0,1,2,3,4,5,6,7,8,9] # 4 bytes * 10 = 40 bytes
    l = []
    for i in range(x):
        l.append(i)
    return l


print(generate_sequence(10))

print("=============================")

def generate_seq_2(x):
    for i in range(x):
        yield x

seq = generate_sequence(10)
for s in seq:
    print(s)