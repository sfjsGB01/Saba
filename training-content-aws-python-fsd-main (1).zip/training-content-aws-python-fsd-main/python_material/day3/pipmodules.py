# Pip modules: 3rd party modules available on the internet (.NET, Ruby: gem, ...)
# 3rd party modules can be developed by either an org like amazon. microsoft etc, or by individual developers
# Pypi: official python repository of 3rd party modules

# pip freeze: gives a list of all the python libraries installed via pip
# pip install <lirbrary_name>: installs library in the system

import requests

r = requests.get('https://httpbin.org/basic-auth/user/pass', auth=('user', 'pass'))
print(r)
print(r.status_code)
print(r.headers['content-type'])
print(r.json())