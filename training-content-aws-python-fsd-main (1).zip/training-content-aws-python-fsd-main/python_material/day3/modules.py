# Inbuilt modules in python
# there are several functionalities python provides to us which are inbuilt
# os, random, math, .... many others
# NOTE: Always prefer to import only what is needed and not the entire module.

import random       # imports the entire random module into the current file, hence makes it bulky
# from random import random,randint
# import math
from math import ceil, pi
# import os
from os import listdir  # imports only a particular function from Os module, hence making the code lighter.

print(listdir())

random_val = random.random()
print(random_val)

print(random.randint(1,100))

print(ceil(4.4))
print(pi)