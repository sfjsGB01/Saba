
names = ["John", "Doe", "Mary"]

# 1.  Loop through values directly
for name in names:
    print(name.upper())

# 2. loop through index positions
# range(3): 0,1,2
for i in range(len(names)):
    print(names[i].upper())

# 3.  Loop through index and values at a single go
for i,v in enumerate(names):
    print(f"index position '{i}' contains the value: '{v}'")

# 4. List comprehensions: Very powerful, used a lot in py programs, definitely asked in interviews specific to py.

upper_names = [name.upper() for name in names]
# ['JOHN', 'DOE', 'MARY']
print(upper_names)


# identify even numbers between 1 to 20
# i = 0
# while i <=20:
#     if i % 2 == 0:
#         print(i)
#     i += 1

# list comprehension with conditions
even_nums = [j for j in range(21) if j % 2 == 0]
print(even_nums)


# Loop through key value pairs in dictionaries
fruit_dict = {
    "apple": 10,
    "Banana": 5,
    "Cherry": 15,
    "jackfruit": 50,
    "mango": {
        "alphonso": 200,
        "TypeX": 20,
        "Kesar": 180
    }
}

print(fruit_dict.items())

for k,v in fruit_dict.items():
    print(f"{k} costs Rs. {v}")