# Strings
s = "My name is aman"
s1 = 'this is a banana' # single quotes and double quotes are treated the same in python.
s2 = "this is aman's laptop"
s3 = 'this is aman\'s laptop'
print(s2)
print(s1)
print(s[0])
print(s[0:5])
print(s[5:])
print(s * 2)
print(s + " and my age is 18")
print(f"length of string s1 is: {len(s1)}") # calculate length of a string