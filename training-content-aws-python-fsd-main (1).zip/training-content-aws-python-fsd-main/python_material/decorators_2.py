def smart_divide(func):
    def inner(a, b):
        print(f'Divding {a} by {b}')
        if b == 0:
            print('Division by 0 is not possible')
            return
        func(a,b)
    return inner


@smart_divide
def divide(a,b):
    print(a/b)

divide(4,2)
divide(2,5)
divide(5,0)