# Slicing: applicable to strings, lists, tuples etc
# syntax: string[first_index:second_index]
# it takes a substring from 1st index to another
# NOTE: first index is inclusive, second index is exclusive (second index+1)
a = "This is Jason speaking"
print(a[8:13])

b = "Jasmine"
print(b[0:3]) # Give me everything from position 0 till position 2. 2+1(3)
print(b[3:])  # give me everything from 3rd position till the end
print(b[:3])  # give me everything from first position till position 2. (2+1=3)

# Negative indexing
print(b[-1:])
# extract last 4 characters of a string
print(b[-4:-2])
print(b[-4:-6])


print(b[3:len(b)-2]) # b[3:5]

print(b[-3])

l = ["Aman", "Sharma", 22, "Georgia", "USA"]
extract = l[2:4]
print(extract)