# Mutability in python
# whether an object can be changed/altered/modified on runtime
# Mutable: lists, sets, dictionary.
# immutable: tuple, int, string, bool

message = "welcome to the training"
#message[0] = "p"
print(message) # results in an error


t = (1,2,3,4)
#t[0] = 11
print(t) # results in an error

# lists
l = [1,2,3,45]
l[0]=11
print(l)
l.append(55)
print(l)