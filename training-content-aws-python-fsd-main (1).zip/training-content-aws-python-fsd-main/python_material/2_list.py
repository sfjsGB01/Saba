
# Lists: not confined to a particular size or variable type.
# lists are mutable which means they can be updated and modified.

l = [1, 2, 3, "string", "aman", 3.3,2,2,3,3]
l1 = [12,13,14]
print(l)
print(l[0])
print(l[3])
print(l[2:4])
print(l[3:])
print(l[:5])

# lists are mutable
l[0] = 100
print(l)
l.append(400)
print(l)

# negative indices
print(l[-1]) #will always be the last value
print(l[-1:-4])
print(l[-4:-1])

# functions with respect to list
print(len(l))

# join 2 lists
print(l+l1)
l.extend(l1)
print(l)
