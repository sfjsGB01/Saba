# Decorators: decorators help changing the behavior of an existing function without changing its code.
# decorators are called from top to bottom based on its sequence.
def star(func):
    def inner(*args, **kwargs):
        print("*************************")
        func(*args, **kwargs)
        print("*************************")
    return inner

def eql(func):
    def inner(*args, **kwargs):
        print("=========================")
        func(*args, **kwargs)
        print("=========================")
    return inner

@eql
@star
def greet(msg):
    print(msg)

greet("Hello from India")

@eql
def add(a,b):
    print(a+b)

add(20,30)

'''
*************************
=========================
Hello from India
=========================
*************************
'''