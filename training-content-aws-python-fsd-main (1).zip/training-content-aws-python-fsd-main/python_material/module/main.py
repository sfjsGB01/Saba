# import calculate
from calculate import add, divide, subtract

a = 10
b = 20

print(divide(10, 0))
print(add(a,b))
print(subtract(b,a))
print(divide(10,2))
 