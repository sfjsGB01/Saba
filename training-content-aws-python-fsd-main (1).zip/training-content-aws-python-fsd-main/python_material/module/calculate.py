# This file is meant to handle math ops

def add(x, y):
    return x+y

def subtract(x, y):
    return x-y

def multiply(x, y):
    return x*y

def divide(x, y):
    try:
        return x/y
    except Exception as ex:
        print(f"Division by 0 is not allowed: {ex}")
        return 0